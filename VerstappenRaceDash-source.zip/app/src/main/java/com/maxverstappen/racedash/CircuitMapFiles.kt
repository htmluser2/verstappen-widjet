package com.maxverstappen.racedash

object CircuitMapFiles {
    private val filesByCircuitKey = mapOf(
        2 to "gb-1948",
        4 to "hu-1986",
        7 to "be-1925",
        9 to "us-2012",
        10 to "au-1953",
        12 to "my-1999",
        14 to "br-1940",
        15 to "es-1991",
        19 to "at-1969",
        22 to "mc-1929",
        23 to "ca-1978",
        39 to "it-1922",
        46 to "jp-1962",
        49 to "cn-2004",
        55 to "nl-1948",
        61 to "sg-2008",
        63 to "bh-2002",
        65 to "mx-1962",
        70 to "ae-2009",
        144 to "az-2016",
        149 to "sa-2021",
        150 to "qa-2004",
        151 to "us-2022",
        152 to "us-2023",
        153 to "es-2026"
    )

    fun forCircuitKey(circuitKey: Int): String? = filesByCircuitKey[circuitKey]
}
